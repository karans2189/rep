This is the README document for the upgradation of kernel.

		1	rep.list is Bullseyes repo.

		2	upgrade_kernel_linux.doc  is Document to be followed.


		3    gpg-key.sh Run the script if you got KEY error(Run this bash after installing apt-keyring).




